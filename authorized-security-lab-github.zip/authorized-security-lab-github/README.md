# Authorized Security Lab

## Overview
This repository documents an authorized, isolated security testing laboratory built for security assessment practice, asset inventory, threat modeling, controlled validation, evidence handling, and reporting.

## Scope
Only the following assets are authorized for testing:

| Asset ID | Asset | Address | Scope |
|---|---|---|---|
| LAB-01 | Local Training Web Application | `127.0.0.1:8080` | In Scope |
| LAB-02 | Deliberately Vulnerable VM | `192.168.56.20` | In Scope |

Any system not explicitly listed in the approved asset inventory is out of scope.

## Out of Scope
- Production and third-party systems
- Public Internet targets
- Systems not listed in the approved inventory
- Denial-of-Service testing
- Destructive payloads
- Persistence
- Credential reuse against unauthorized systems
- Uncontrolled data extraction

## Threat Model
The lab uses STRIDE:
- Spoofing
- Tampering
- Repudiation
- Information Disclosure
- Denial of Service
- Elevation of Privilege

DoS is documented as a threat scenario only; active DoS testing is excluded.

## Rules of Engagement
Testing is limited to the approved isolated lab, permitted techniques, defined testing window, and safe stop conditions. Evidence is minimized and sensitive information is redacted.

## Repository Structure
```text
authorized-security-lab/
├── README.md
├── documentation/
│   └── Authorized_Security_Lab_Dossier.docx
├── scope/
│   └── asset-inventory.csv
├── threat-model/
│   └── stride-register.md
├── rules-of-engagement/
│   └── rules-of-engagement.md
├── diagrams/
│   └── data-flow-diagram.png
└── evidence/
    └── README.md
```

## Safety Notice
This project is intended only for authorized security testing in an isolated laboratory. Do not apply these activities to systems without explicit authorization.
