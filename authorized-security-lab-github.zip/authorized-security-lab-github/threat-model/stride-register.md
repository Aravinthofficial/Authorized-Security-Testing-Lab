# STRIDE Threat Register

| ID | STRIDE | Asset | Threat / Abuse Case | Risk | Mitigation |
|---|---|---|---|---|---|
| S-01 | Spoofing | LAB-01 | Unauthorized identity use | High | Strong authentication and session controls |
| T-01 | Tampering | LAB-01 | Unauthorized modification of application data | High | Server-side validation and authorization |
| R-01 | Repudiation | LAB-01 | Security-relevant actions are not adequately logged | Medium | Audit logging and monitoring |
| I-01 | Information Disclosure | LAB-01 | Sensitive information exposed through application behavior | High | Access controls and secure error handling |
| D-01 | Denial of Service | LAB-01 | Availability could be affected by resource exhaustion | High | Rate limiting and resource controls |
| E-01 | Elevation of Privilege | LAB-02 | Low-privilege user gains unauthorized higher privileges | High | Least privilege and authorization checks |

> **Scope note:** Denial-of-Service is included as a threat-model scenario only. Active DoS testing is excluded from this engagement.
