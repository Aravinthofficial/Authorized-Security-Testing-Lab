# Authorized Security Lab — Rules of Engagement

## 1. Written Authorization
- Lab Owner: `[Lab Owner / Organization]`
- Security Assessor: `[Your Name]`
- Approval Date: `[DD/MM/YYYY]`
- Approved assets: LAB-01 and LAB-02
- Never test a system absent from the approved asset inventory.

## 2. Permitted Activities
- Asset identification within the approved lab
- Service identification within authorized assets
- Application security validation
- Non-destructive vulnerability verification
- Minimum necessary evidence collection
- Security documentation and reporting

## 3. Explicit Exclusions
- Denial-of-Service testing
- Destructive payloads
- Persistence
- Credential reuse against unauthorized systems
- Third-party targets
- Uncontrolled data extraction
- Any asset not listed in the approved inventory

## 4. Testing Window and Stop Conditions
- Start: `[DD/MM/YYYY HH:MM]`
- End: `[DD/MM/YYYY HH:MM]`
- Emergency Contact: `[Name / Contact]`
- Rate Limits: `[Define safe lab limits]`

Immediately stop if:
- unexpected service disruption occurs;
- an out-of-scope system is contacted;
- sensitive data is unexpectedly exposed;
- traffic leaves the authorized lab unexpectedly;
- destructive impact becomes possible;
- the testing window expires; or
- the lab owner requests testing to stop.

## 5. Evidence Handling
Store only the minimum evidence required to demonstrate a finding. Redact secrets and personal data. Store evidence securely and define an appropriate deletion/retention period.

## 6. Reporting
For each finding record:
- Asset
- Severity and rationale
- Reproduction steps
- Impact
- Evidence
- Remediation
