# Evidence

Store only evidence generated from the authorized lab.

Before committing evidence:
- Remove passwords, API keys, tokens, and other secrets.
- Redact personal information.
- Do not include data from out-of-scope systems.
- Keep only the minimum evidence needed to demonstrate a finding.

Do not commit raw credentials or sensitive logs to a public repository.
